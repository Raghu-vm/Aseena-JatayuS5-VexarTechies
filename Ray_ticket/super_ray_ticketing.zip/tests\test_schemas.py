"""Schema validation tests."""
import pytest
from pydantic import ValidationError

from app.core.enums import Department, Priority
from app.schemas.ticket import CreateWebhookRequest, LLMExtraction


def test_llm_extraction_valid():
    e = LLMExtraction(
        title="VPN not connecting from home office",
        description="User cannot establish VPN connection from their home WiFi since this morning. Error: timeout after 30s.",
        department=Department.IT_SUPPORT,
        priority=Priority.HIGH,
        impact="User is fully blocked from accessing internal tools.",
    )
    assert e.department == Department.IT_SUPPORT


def test_llm_extraction_bad_department():
    with pytest.raises(ValidationError):
        LLMExtraction(
            title="x" * 5,
            description="x" * 20,
            department="not_a_dept",  # type: ignore[arg-type]
            priority=Priority.LOW,
            impact="impact text",
        )


def test_create_webhook_request_requires_email():
    with pytest.raises(ValidationError):
        CreateWebhookRequest(
            user_email="not-an-email",  # type: ignore[arg-type]
            initiation_query="hello there",
            clarifying_question="what's up?",
            clarifying_answer="not much",
        )
